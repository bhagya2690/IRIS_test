﻿using System;
using OpenQA.Selenium;
using OpenQA.Selenium.Chrome;
using OpenQA.Selenium.Interactions;

namespace IRIS_Test
{
    class Program
    {
        static void Main(string[] args)
        {
            IWebDriver driver = new ChromeDriver(@"C:\chrome_driver");
            driver.Manage().Window.Maximize();
            driver.Navigate().GoToUrl("https://osa-web.t-cg.co.uk");
            System.Threading.Thread.Sleep(2000);
            driver.FindElement(By.Id("main")).SendKeys("B16 8PE");
            driver.FindElement(By.Id("searchPostcodeButton")).Click();
            System.Threading.Thread.Sleep(2000);
            driver.FindElement(By.XPath("//*[@id='root']/div/main/ol/li[20]/h2/strong")).Click();
            System.Threading.Thread.Sleep(2000);
            driver.FindElement(By.XPath("//div[@class='pt-2']//p[contains(text(),'News')]")).Click();
            var news = driver.FindElement(By.XPath("//div[@class='row']//h1[contains(text(),'News')]")).Text;
            news.Equals("News");
            driver.FindElement(By.XPath("//div[@class='pt-2']//p[contains(text(),'qatest')]")).Click();
            var qatest = driver.FindElement(By.XPath("//div[@class='row']//h1[contains(text(),'qatest')]")).Text;
            qatest.Equals("qatest");
            driver.Quit();
        }
    }
}
